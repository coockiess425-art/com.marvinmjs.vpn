# MarvinMJS Demo APK — phone-only build

1. Create a GitHub repository from your Android phone.
2. Upload the contents of this project to the repository.
3. Open **Actions**.
4. Select **Build MarvinMJS Demo APK**.
5. Tap **Run workflow**.
6. When the workflow completes, open the run and download the
   **MarvinMJS-demo-apk** artifact.
7. Extract `MarvinMJS-demo.apk` and install it on your Android phone.

This workflow builds the debug APK in GitHub Actions. It does not require
Android Studio on the phone.

Demo scope:
- MarvinMJS UI and SA server/profile selection.
- Demo connection state only.
- No real VPN tunnel.
- No carrier zero-rating or restriction bypass.
