# MarvinMJS VPN

Android WireGuard client template focused on South African server profiles.

## API levels
- minSdk 23
- targetSdk 36
- compileSdk 36

## Profiles
- MTN SA
- Vodacom SA
- Telkom SA
- Cell C SA
- Rain SA

## Build
See `BUILD_APK.md`. The WireGuard Android tunnel library is embedded as a Maven dependency. The upstream project documents Maven embedding and Java 17/desugaring requirements. See the official WireGuard Android repository for current build guidance.

## Server configuration
The included `.conf` files intentionally contain placeholders. They do not provide carrier bypass or zero-rating. Insert valid WireGuard credentials and an endpoint for a server you control or are authorized to use.
