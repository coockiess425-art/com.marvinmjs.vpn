package com.marvinmjs.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.BackendException
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets

class MainActivity : AppCompatActivity() {
    private lateinit var serverSpinner: Spinner
    private lateinit var connectButton: Button
    private lateinit var statusText: TextView

    private val backend by lazy { GoBackend(applicationContext) }
    private var activeTunnel: Tunnel? = null
    private var pendingProfile: ServerProfile? = null

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                pendingProfile?.let { connect(it) }
            } else {
                showStatus("VPN permission denied")
            }
        }

    private val servers = listOf(
        ServerProfile("MTN SA", "MTN-SA.conf"),
        ServerProfile("Vodacom SA", "Vodacom-SA.conf"),
        ServerProfile("Telkom SA", "Telkom-SA.conf"),
        ServerProfile("Cell C SA", "CellC-SA.conf"),
        ServerProfile("Rain SA", "Rain-SA.conf")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updateUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = "MarvinMJS VPN"
            textSize = 28f
        }
        val subtitle = TextView(this).apply {
            text = "South Africa VPN Tunnel"
            textSize = 16f
        }

        serverSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                servers.map { it.name }
            )
        }

        statusText = TextView(this).apply {
            textSize = 17f
            setPadding(0, 32, 0, 32)
        }

        connectButton = Button(this).apply {
            text = "Connect"
            setOnClickListener {
                val current = activeTunnel
                if (current == null) {
                    requestVpnPermission(servers[serverSpinner.selectedItemPosition])
                } else {
                    disconnect(current)
                }
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(serverSpinner)
        root.addView(statusText)
        root.addView(connectButton)
        setContentView(root)
    }

    private fun requestVpnPermission(profile: ServerProfile) {
        pendingProfile = profile
        val intent = VpnService.prepare(this)
        if (intent == null) {
            connect(profile)
        } else {
            vpnPermissionLauncher.launch(intent)
        }
    }

    private fun connect(profile: ServerProfile) {
        showStatus("Loading ${profile.name}…")
        connectButton.isEnabled = false

        Thread {
            try {
                val configText = assets.open("configs/${profile.configFile}")
                    .bufferedReader()
                    .use { it.readText() }

                if (configText.contains("REPLACE_WITH_")) {
                    throw IllegalStateException(
                        "${profile.name} is a template. Add a real WireGuard server configuration first."
                    )
                }

                val config = Config.parse(
                    ByteArrayInputStream(configText.toByteArray(StandardCharsets.UTF_8))
                )

                val tunnel = AppTunnel(profile.name)
                backend.setState(tunnel, Tunnel.State.UP, config)
                activeTunnel = tunnel
                pendingProfile = null

                runOnUiThread {
                    showStatus("Connected: ${profile.name}")
                    connectButton.text = "Disconnect"
                    connectButton.isEnabled = true
                }
            } catch (e: BackendException) {
                runOnUiThread {
                    activeTunnel = null
                    showStatus("Connection failed: ${e.reason}")
                    connectButton.text = "Connect"
                    connectButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    activeTunnel = null
                    showStatus("Connection failed: ${e.message ?: "Unknown error"}")
                    connectButton.text = "Connect"
                    connectButton.isEnabled = true
                    Toast.makeText(this, e.message ?: "Connection failed", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun disconnect(tunnel: Tunnel) {
        connectButton.isEnabled = false
        showStatus("Disconnecting…")
        Thread {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN)
            } catch (e: Exception) {
                runOnUiThread { showStatus("Disconnect failed: ${e.message}") }
            } finally {
                activeTunnel = null
                runOnUiThread {
                    showStatus("Disconnected")
                    connectButton.text = "Connect"
                    connectButton.isEnabled = true
                }
            }
        }.start()
    }

    private fun updateUi() {
        showStatus("Disconnected")
        connectButton.text = "Connect"
    }

    private fun showStatus(message: String) {
        statusText.text = "Status: $message"
    }

    override fun onDestroy() {
        activeTunnel?.let { tunnel ->
            Thread {
                runCatching { backend.setState(tunnel, Tunnel.State.DOWN) }
            }.start()
        }
        super.onDestroy()
    }

    private class AppTunnel(private val tunnelName: String) : Tunnel {
        override fun getName(): String = tunnelName
        override fun onStateChange(newState: Tunnel.State) = Unit
    }

    data class ServerProfile(val name: String, val configFile: String)
}
