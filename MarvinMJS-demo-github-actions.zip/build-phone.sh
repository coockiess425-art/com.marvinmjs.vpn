#!/data/data/com.termux/files/usr/bin/bash
set -e
if ! command -v curl >/dev/null 2>&1; then echo "Install curl first: pkg install curl"; exit 1; fi
if ! command -v unzip >/dev/null 2>&1; then echo "Install unzip first: pkg install unzip"; exit 1; fi
if ! command -v java >/dev/null 2>&1; then echo "Install Java 17 first: pkg install openjdk-17"; exit 1; fi
GRADLE_VERSION=8.13
CACHE="$HOME/.marvinmjs/gradle-$GRADLE_VERSION"
if [ ! -x "$CACHE/bin/gradle" ]; then
  mkdir -p "$HOME/.marvinmjs"
  curl -L "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "$HOME/.marvinmjs/gradle.zip"
  rm -rf "$CACHE" "$HOME/.marvinmjs/gradle-$GRADLE_VERSION"
  unzip -q "$HOME/.marvinmjs/gradle.zip" -d "$HOME/.marvinmjs"
  mv "$HOME/.marvinmjs/gradle-$GRADLE_VERSION" "$CACHE"
fi
"$CACHE/bin/gradle" --no-daemon assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
